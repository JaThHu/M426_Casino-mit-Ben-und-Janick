﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Unittest_Slotmachine_3
{
    public class ConsoleInput : IDisposable
    {
        private readonly TextReader originalInput;
        private readonly StringReader mockInput;

        public ConsoleInput(string input)
        {
            originalInput = Console.In;
            mockInput = new StringReader(input);
            Console.SetIn(mockInput);
        }

        public void Dispose()
        {
            Console.SetIn(originalInput);
            mockInput.Dispose();
        }
    }
}
