﻿namespace LB426_LB_Ben
{
    using System;

    class Program
    {
        static void Main(string[] args)
        {
            var machine = new SlotMachine();

          
            machine.AddSymbol(new Symbol("Cherry", 10, ConsoleColor.Red));
            machine.AddSymbol(new Symbol("Orange", 20, ConsoleColor.Yellow));
            machine.AddSymbol(new Symbol("Lemon", 30, ConsoleColor.Green));

            machine.StartGame();
        }
    }


}
