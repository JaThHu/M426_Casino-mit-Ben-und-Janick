﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace LB426_LB_Ben
{
    public class SlotMachine
    {
        private List<Symbol> symbols = new List<Symbol>();
        private int playerChips = 100; // Startguthaben

        public void AddSymbol(Symbol symbol)
        {
            symbols.Add(symbol);
        }

        public void StartGame()
        {
            Console.WriteLine("Willkommen zur Slotmaschine!");

            while (playerChips > 0)
            {
                Console.WriteLine("Dein aktuelles Guthaben: " + playerChips + " Chips");

                Console.WriteLine("Bitte gib deinen Einsatz (zwischen 1 und " + playerChips + " Chips) ein:");
                int betAmount = GetBetAmount();

                Spin(betAmount);

                if (playerChips <= 0)
                {
                    Console.WriteLine("Du hast keine Chips mehr. Das Spiel endet.");
                    break;
                }
            }

            Console.WriteLine("Vielen Dank fürs Spielen! Dein Endguthaben beträgt: " + playerChips + " Chips");
        }

        public int GetBetAmount()
        {
            int betAmount;
            while (true)
            {
                if (int.TryParse(Console.ReadLine(), out betAmount))
                {
                    if (betAmount >= 1 && betAmount <= playerChips)
                    {
                        return betAmount;
                    }
                }
                Console.WriteLine("Ungültiger Einsatz. Bitte gib einen Einsatz zwischen 1 und " + playerChips + " Chips ein:");
            }
        }

        private void Spin(int betAmount)
        {
            Random random = new Random();
            Symbol[] result = new Symbol[3];

            for (int i = 0; i < 3; i++)
            {
                int randomIndex = random.Next(symbols.Count);
                result[i] = symbols[randomIndex];
            }

            DisplayResult(result, betAmount);
        }

        private void DisplayResult(Symbol[] result, int betAmount)
        {
            Console.WriteLine("Ergebnis:");

            foreach (var symbol in result)
            {
                Console.WriteLine(symbol.Name);
            }

            int totalWin = CalculateWin(result, betAmount);
            Console.WriteLine("Gewinn: " + totalWin + " Chips");

            playerChips += totalWin - betAmount;
            Console.WriteLine("Aktuelles Guthaben: " + playerChips + " Chips");
        }

        private int CalculateWin(Symbol[] result, int betAmount)
        {
            int totalWin = 0;

            if (result[0].Name == result[1].Name && result[1].Name == result[2].Name)
            {
                totalWin = result[0].Value * betAmount;
            }

            return totalWin;
        }
    }
}