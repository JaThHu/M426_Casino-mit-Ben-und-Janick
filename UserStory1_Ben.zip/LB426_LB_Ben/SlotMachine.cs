﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace LB426_LB_Ben
{
    public class SlotMachine
    {
        private List<Symbol> symbols = new List<Symbol>();
        private int playerChips = 100; // Startguthaben

        public void AddSymbol(Symbol symbol)
        {
            symbols.Add(symbol);
        }

        public void StartGame()
        {
            Console.WriteLine("Willkommen zur Slotmaschine!");

            while (playerChips > 0)
            {
                Console.WriteLine("Dein aktuelles Guthaben: " + playerChips + " Chips");

                int betAmount = 50; // Automatischer Einsatz von 50 Chips

                Spin(betAmount);

                if (playerChips <= 0)
                {
                    Console.WriteLine("Du hast keine Chips mehr. Das Spiel endet.");
                    break;
                }

                // Nach jedem Spin warten, bis der Spieler Enter drückt
                Console.WriteLine("Drücke Enter, um fortzufahren...");
                Console.ReadLine();
            }

            Console.WriteLine("Vielen Dank fürs Spielen! Dein Endguthaben beträgt: " + playerChips + " Chips");
        }

        private void Spin(int betAmount)
        {
            Random random = new Random();
            Symbol[] result = new Symbol[3];

            for (int i = 0; i < 3; i++)
            {
                int randomIndex = random.Next(symbols.Count);
                result[i] = symbols[randomIndex];
            }

            DisplayResult(result, betAmount);
        }

        private void DisplayResult(Symbol[] result, int betAmount)
        {
            Console.WriteLine("Ergebnis:");

            foreach (var symbol in result)
            {
                Console.WriteLine(symbol.Name);
            }

            int totalWin = CalculateWin(result, betAmount);
            Console.WriteLine("Gewinn: " + totalWin + " Chips");

            playerChips += totalWin - betAmount;
            Console.WriteLine("Aktuelles Guthaben: " + playerChips + " Chips");
        }

        private int CalculateWin(Symbol[] result, int betAmount)
        {
            int totalWin = 0;

            if (result[0].Name == result[1].Name && result[1].Name == result[2].Name)
            {
                totalWin = result[0].Value * betAmount;
            }

            return totalWin;
        }
    }
}