namespace Unittest_Slotmachine_1
{
    [TestClass]
    public class UnitTest1


    {
        [TestClass]
        public class SlotMachineTests
        {
            [TestMethod]
            public void GetBetAmount_ValidInput_ReturnsValidBetAmount()
            {

                var machine = new LB426_LB_Ben.SlotMachine();
                int expectedBetAmount = 50;
                string input = "50\n"; // Simuliere Benutzereingabe


                using (var consoleInput = new ConsoleInput(input))
                {
                    int actualBetAmount = machine.GetBetAmount();


                    Assert.AreEqual(expectedBetAmount, actualBetAmount);
                }
            }
        }
    }
}